import { useState } from 'react';

function App() {
  const [query, setQuery] = useState('');
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const searchMovies = async (e) => {
    e.preventDefault();
    if (!query.trim()) return; // prevent empty search
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`https://www.omdbapi.com/?s=${query}&apikey=be1fabd1`);
      const data = await res.json();
      if (data.Response === "True") {
        setMovies(data.Search);
      } else {
        setMovies([]);
        setError(data.Error); // e.g., "Movie not found!"
      }
    } catch (err) {
      console.error(err);
      setError('Something went wrong. Please try again later.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-5">
      <h1 className="text-3xl font-bold text-center mb-8">Movie Search</h1>
      
      <form onSubmit={searchMovies} className="flex justify-center mb-8">
        <input 
          type="text" 
          className="w-1/2 p-2 rounded-l bg-gray-700 placeholder-gray-400 focus:outline-none" 
          placeholder="Search for movies..." 
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button 
          type="submit" 
          className="p-2 bg-blue-600 rounded-r hover:bg-blue-700 transition"
        >
          Search
        </button>
      </form>

      {loading && <p className="text-center">Loading...</p>}

      {error && <p className="text-center text-red-400 mb-4">{error}</p>}

      {!loading && !error && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {movies.map((movie) => (
            <div key={movie.imdbID} className="bg-gray-800 p-4 rounded shadow">
              <img 
                src={movie.Poster !== 'N/A' ? movie.Poster : 'https://via.placeholder.com/150'} 
                alt={movie.Title} 
                className="w-full h-64 object-cover mb-4 rounded"
              />
              <h2 className="text-lg font-semibold">{movie.Title}</h2>
              <p className="text-gray-400">{movie.Year}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
