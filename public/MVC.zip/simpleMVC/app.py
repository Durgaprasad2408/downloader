# app.py

from flask import Flask, render_template
from models import get_items

app = Flask(__name__)

@app.route('/')
def home():
    items = get_items()  # Get data from the model
    return render_template('home.html', items=items)  # Pass it to the view

if __name__ == '__main__':
    app.run(debug=True)
