# controller.py
from model import MessageModel
from view import MessageView

class MessageController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def set_message(self, message):
        self.model.set_message(message)

    def update_view(self):
        message = self.model.get_message()
        self.view.show_message(message)
