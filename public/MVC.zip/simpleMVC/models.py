# models.py

class Item:
    def __init__(self, name, price):
        self.name = name
        self.price = price

def get_items():
    # Simulated database
    return [
        Item(name="Apple", price=0.5),
        Item(name="Banana", price=0.3),
        Item(name="Orange", price=0.7)
    ]
