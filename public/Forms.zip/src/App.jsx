import React, { useRef } from 'react';
import ControlledForm from './ControlledForm';

const UncontrolledForm = () => {
  const nameRef = useRef();
  const emailRef = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({
      name: nameRef.current.value,
      email: emailRef.current.value
    });
  };

  return (
    <>
    <h3>Uncontrolled Form</h3>
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name:</label>
        <input
          type="text"
          ref={nameRef}
        />
      </div>
      <div>
        <label>Email:</label>
        <input
          type="email"
          ref={emailRef}
        />
      </div>
      <button type="submit">Submit</button>
    </form>
    <h3>Controlled Form</h3>
    <ControlledForm />
    </>
  );
};

export default UncontrolledForm;
