import React, { useRef } from 'react';

const UncontrolledForm = () => {
  const nameRef = useRef();
  const emailRef = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({
      name: nameRef.current.value,
      email: emailRef.current.value
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name:</label>
        <input
          type="text"
          ref={nameRef}
        />
      </div>
      <div>
        <label>Email:</label>
        <input
          type="email"
          ref={emailRef}
        />
      </div>
      <button type="submit">Submit</button>
    </form>
  );
};

export default UncontrolledForm;
