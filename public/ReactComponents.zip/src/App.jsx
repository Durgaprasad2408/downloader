import React, { useState } from 'react';
import Counter from './assets/Counter';

function App() {
  // Declare a state variable `count` and a function to update it, `setCount`
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={() => setCount(count - 1)}>Decrement</button>

      <Counter /> 
    </div>
  );
}


// Remove the <COunter /> if you don't want Class components.
export default App;
