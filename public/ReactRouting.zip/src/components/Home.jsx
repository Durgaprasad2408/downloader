import React from 'react';

const Home = () => {
  return <h2>Home Page</h2>;
};

export default Home;
