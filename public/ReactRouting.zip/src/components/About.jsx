import React from 'react';

const About = () => {
  return <h2>About Us</h2>;
};

export default About;
